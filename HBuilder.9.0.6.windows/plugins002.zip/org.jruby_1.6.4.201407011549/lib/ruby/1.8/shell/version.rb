#
#   version.rb - shell version definition file
#   	$Release Version: 0.6.0$
#   	$Revision$
#   	$Date$
#   	by Keiju ISHITSUKA(Nihon Rational Software Co.,Ltd)
#
# --
#
#   
#

class Shell
  @RELEASE_VERSION = "0.6.0"
  @LAST_UPDATE_DATE = "01/03/19"
end
