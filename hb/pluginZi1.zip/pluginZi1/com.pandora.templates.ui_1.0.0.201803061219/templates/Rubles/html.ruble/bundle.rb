require 'ruble'

bundle do |bundle|
  bundle.author = ''
  bundle.copyright = ""
  bundle.display_name = t(:bundle_name)
  bundle.description = t(:bundle_description)
  bundle.repository = ""
  
end
