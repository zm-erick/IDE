def indent(level = 0)
  " " * level * 4 # FIXME Should use type/length of indent specified in ENV vars!
end