# jQuery bundle for Aptana Studio

A bundle to enable related commands in Aptana Studio. Ported from a http://github.com/kswedberg/jquery-tmbundle.

## Authors

* Karl Swedberg
* Jonathan Chaffer
* Modifications by Aptana

## License

This bundle is dual-licensed under MIT and GPL licenses:

* [http://www.opensource.org/licenses/mit-license.php](http://www.opensource.org/licenses/mit-license.php)
* [http://www.gnu.org/licenses/gpl.html](http://www.gnu.org/licenses/gpl.html)

## Bugs/Requests

* You can [report a bug or request a feature here](http://github.com/aptana/javascript-jquery.ruble/issues)