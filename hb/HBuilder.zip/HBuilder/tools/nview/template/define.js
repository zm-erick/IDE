define('/*{MODULE}*/', function (require, module) {
    /*{CODE}*/
});